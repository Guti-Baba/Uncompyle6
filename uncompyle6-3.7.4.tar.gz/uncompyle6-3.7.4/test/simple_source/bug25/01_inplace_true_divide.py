# Force INPLACE_TRUE_DIVIDE opcode
from __future__ import division
x = len(__file__)
x /= 2
